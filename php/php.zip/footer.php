<?php 


//this file is used by files kept in the php directory//

echo '
  <script type="text/javascript " src="../script.js"></script>
</body>
</html>
'


?>