<?php 

include 'dbh.php';
include 'functions.php';

?>
<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
	<title>
		MY COLLEGE CANTEEN 
	</title>

	<link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,500,600,700" rel="stylesheet">  
    <link rel="stylesheet" type="text/css" href="./style.css">
    <link rel="stylesheet" type="text/css" href="../style.css">
    <link rel ="stylesheet" href="./icon-fonts.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 

</head>
<body>

